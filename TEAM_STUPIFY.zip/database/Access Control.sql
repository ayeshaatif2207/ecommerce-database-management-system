use stupify;

-- 1. ADMIN ROLE - Full access to everything
CREATE USER 'admin_2'@'localhost' IDENTIFIED BY 'admin_pass123';
GRANT ALL PRIVILEGES ON stupify.* TO 'admin_2'@'localhost';
-- 2. manager ROLE - Can view and add products, but not delete
CREATE USER 'database_manager'@'localhost' IDENTIFIED BY 'manager_pass_123';
GRANT SELECT, INSERT, UPDATE ON stupify.product TO 'database_manager'@'localhost';
GRANT SELECT ON stupify.category TO 'database_manager'@'localhost';
GRANT SELECT ON stupify.customer TO 'database_manager'@'localhost';
GRANT SELECT ON stupify.`order` TO 'database_manager'@'localhost';
SHOW GRANTS FOR 'database_manager'@'localhost';

-- 3. ANALYST ROLE - Read-only access
CREATE USER 'analyst'@'localhost' IDENTIFIED BY 'analyst_pass_123';
GRANT SELECT ON stupify.* TO 'analyst'@'localhost';
-- Apply changes
FLUSH PRIVILEGES;
